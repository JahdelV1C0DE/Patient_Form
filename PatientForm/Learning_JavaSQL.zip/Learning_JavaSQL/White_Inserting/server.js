'use strict';
var fs = require('fs');
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();

const mysql = require('mysql2');

const con = mysql.createConnection({
    host:"istwebclass.org",
    user:"jwhite70_JahdelWhite",
    password:"Miles04#",
    database: "jwhite70_Lab1Database",

});

con.connect(function (err){
    if (err) throw err;
    console.log("Connected!");
    });

app.set('port', (process.env.PORT || 3000));

app.use('/', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

    

    
app.listen(app.get('port'), function () {
    console.log('Server started: http://localhost:' + app.get('port') + '/');
});

app.use(bodyParser.urlencoded({ extended: true}));

app.get('/', function (req, res){
    res.sendFile(path.join(__dirname + 'public/insertemployee.html'));
});

app.post('/customer', function (req, res) {
    var cname = req.body.customername;
    var caddress = req.body.customeraddress;
    var czip = req.body.customerzip;
    var ccredit = req.body.customercredit;
    var cemail = req.body.customeremail;
    console.log(cname);
    // Rest of your code
    //question marks represent the values that will be entered into the query

var sqlins = "INSERT INTO customertable (dbcustomername, dbcustomeraddress, dbcustomerzip, "
    + " dbcustomercredit, dbcustomeremail) VALUES (?, ?, ?, ?, ?)";

var inserts = [cname, caddress, czip, ccredit, cemail];

var sql = mysql.format(sqlins, inserts);

con.execute(sql, function (err, result){
    if (err) throw err;
    console.log("1 record inserted");
    res.direct('insertcustomer.html');
    res.end();
});


});