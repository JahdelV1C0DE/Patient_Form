'use strict';
var fs = require('fs');
var path = require('path');
var express = require('express');
var bodyParser = require('body-parser');
var app = express();

const mysql = require('mysql2');

const con = mysql.createConnection({
    host:"istwebclass.org",
    user:"jwhite70_JahdelWhite",
    password:"Miles04#",
    database: "jwhite70_Lab1Database",

});

con.connect(function (err){
    if (err) throw err;
    console.log("Connected!");
    });

app.set('port', (process.env.PORT || 3000));

app.use('/', express.static(path.join(__dirname, 'public')));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

    

    
app.listen(app.get('port'), function () {
    console.log('Server started: http://localhost:' + app.get('port') + '/');
});

app.use(bodyParser.urlencoded({ extended: true}));

app.get('/', function (req, res){
    res.sendFile(path.join(__dirname, + 'public/insertemployee.html'));
});

app.get('/getemp', function (req, res) {
    //query is for inserts
    var eid = req.query.employeeid;
    var ename = req.query.employeename;
    var ephone = req.query.employeephone;
    var eemail = req.query.employeeemail;
    var esalary = req.query.employeesalary;


var sqlsel = 'Select * from employeetable where dbemployeeid Like ? and dbemployeename Like ? and dbemployeephone Like?'
    + ' and dbemployeeemail Like ? and dbemployeesalary Like ?';

var inserts = ['%' + eid + '%', '%' + ename + '%', '%' + ephone + '%', '%', eemail + '%', '%' + esalary + '%'];
var sql = mysql.format(sqlsel, inserts);

console.log(sql);

con.query(sql, function (err, data){
    if (err) {
        console.error(err);
        process.exit(1);
    }
    res.send(JSON.stringify(data));

    });

});

app.get('/getcustomer', function (req, res) {
    //query is for inserts
    var customername = req.query.customername;
    var customeraddress = req.query.customeraddress;
    var customerzip = req.query.customerzip;
    var customercredit = req.query.customercredit;
    var customeremail = req.query.customeremail;

    var sqlsel = 'Select * from customertable where dbcustomername Like ? and dbcustomeraddress Like ? and dbcustomerzip Like?'
    + ' and dbcustomercredit Like ? and dbcustomeremail Like ?';


var inserts = ['%' + customername + '%', '%' + customeraddress + '%', '%' + customerzip + '%', '%', customercredit + '%', '%' + customeremail + '%'];

var sql = mysql.format(sqlsel, inserts);

console.log(sql);

con.query(sql, function (err, data){
    if (err) {
        console.error(err);
        process.exit(1);
    }
    res.send(JSON.stringify(data));

    });

});
app.post('/customer', function (req, res) {
    //body is for grabbing data
    var customername = req.body.customername;
    var customeraddress = req.body.customeraddress;
    var customerzip = req.body.customerzip;
    var customercredit = req.body.customercredit;
    var customeremail = req.body.customeremail;
    console.log(customername);
    

var sqlins = "INSERT INTO customertable (dbcustomername, dbcustomeraddress, dbcustomerzip, "
    + " dbcustomercredit, dbcustomeremail) VALUES (?, ?, ?, ?, ?)";

var inserts = [customername, customeraddress, customerzip, customercredit, customeremail];

var sql = mysql.format(sqlins, inserts);

con.execute(sql, function (err, result){
    if (err) throw err;
    console.log("1 record inserted");
    res.redirect('insertcustomer.html');
    res.end();
});


});