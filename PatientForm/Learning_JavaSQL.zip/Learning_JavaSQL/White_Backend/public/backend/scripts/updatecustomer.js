var CustomerBox = React.createClass({
    getInitialState: function () {
        return { data: [] };
    },
    loadCustomersFromServer: function () {

        var cmembervalue = 2;
        if (custmemberyes.checked) {
            cmembervalue = 1;
        } 
        if (custmemberno.checked) {
            cmembervalue = 0;
        }
        console.log(cmembervalue);
        $.ajax({
            url: '/getc',
            data: {
                'customername': customername.value,
                'customeraddress': customeraddress.value,
                'customerzip': customerzip.value,
                'customercredit': customercredit.value,
                'customeremail': customeremail.value,
                'customermember': cmembervalue,
                'customertype': custtype.value
            },
            
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });

    },
    updateSingleCustFromServer: function (customer) {
        
        $.ajax({
            url: '/updatesinglecust',
            dataType: 'json',
            data: customer,
            type: 'POST',
            cache: false,
            success: function (upsingledata) {
                this.setState({ upsingledata: upsingledata });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        window.location.reload(true);
    },
    componentDidMount: function () {
        this.loadCustomersFromServer();
       // setInterval(this.loadEmployeesFromServer, this.props.pollInterval);
    },

    render: function () {
        return (
            <div>
                <h1>Update Customers</h1>
                <Customerform2 onCustomerSubmit={this.loadCustomersFromServer} />
                <br />
                <div id = "theresults">
                    <div id = "theleft">
                    <table>
                        <thead>
                            <tr>
                                <th>Key</th>
                                <th>Name</th>
                                <th>Address</th>
                                <th>Zip</th>
                                <th></th>
                            </tr>
                         </thead>
                        <CustomerList data={this.state.data} />
                    </table>
                    </div>
                    <div id="theright">
                        <CustomerUpdateform onUpdateSubmit={this.updateSingleCustFromServer} />
                    </div>                
                </div>
            </div>
        );
    }
});

var Customerform2 = React.createClass({
    getInitialState: function () {
        return {
            customername: "",
            customeraddress: "",
            customerzip: "",
            customercredit: "",
            customeremail: "",
            customermember: "",
            data: []
        };
    },
    handleOptionChange: function (e) {
        this.setState({
            selectedOption: e.target.value
        });
    },
    loadCustTypes: function () {
        $.ajax({
            url: '/getctypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ data: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function() {
        this.loadCustTypes();
    },

    handleSubmit: function (e) {
        e.preventDefault();

        var customername = this.state.customername.trim();
        var customeraddress = this.state.customeraddress.trim();
        var customerzip = this.state.customerzip.trim();
        var customercredit = this.state.customercredit.trim();
        var customeremail = this.state.customeremail.trim();
        var customermember = this.state.selectedOption;
        var customertype = custtype.value;

        this.props.onCustomerSubmit({ 
            customername: customername,
            customeraddress: customeraddress,
            customerzip: customerzip,
            customercredit: customercredit, 
            customeremail: customeremail,
            customermember: customermember,
            customertype: customertype
        });

    },
    handleChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
        <div>
            <div id = "theform">
            <form onSubmit={this.handleSubmit}>
                <h2>Customers</h2>
                <table>
                    <tbody>
                        <tr>
                            <th>Customer Name</th>
                            <td>
                                <input type="text" name="customername" id="customername" value={this.state.customername} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer Address</th>
                            <td>
                                <input name="customeraddress" id="customeraddress" value={this.state.customeraddress} onChange={this.handleChange}  />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer Zip</th>
                            <td>
                                <input name="customerzip" id="customerzip" value={this.state.customerzip} onChange={this.handleChange} />
                            </td>
                        </tr>
                        <tr>
                            <th>Customer Credit</th>
                            <td>
                                <input name="customercredit" id="customercredit" value={this.state.customercredit} onChange={this.handleChange} />
                            </td>
                        </tr>

                        <tr>
                            <th>Customer Email</th>
                            <td>
                                <input name="customeremail" id="customeremail" value={this.state.customeremail} onChange={this.handleChange} />
                            </td>
                        </tr>

                        <tr>
                            <th>Become a Discount Member</th>
                            <td>
                                <input
                                    type="radio" 
                                    name="custmember" 
                                    id="custmemberyes" 
                                    value="1"
                                    checked={this.state.selectedOption === "1"}
                                    onChange={this.handleOptionChange} 
                                    className="form-check-input"
                                />Discount Member
                                <input
                                    type="radio" 
                                    name="custmember" 
                                    id="custmemberno" 
                                    value="0"
                                    checked={this.state.selectedOption === "0"}
                                    onChange={this.handleOptionChange} 
                                    className="form-check-input"
                                />Normal Member
                            </td>
                        </tr>
                        <tr>
                            <th>Reward Status</th>
                            <td>
                                <SelectList data={this.state.data} />
                            </td>
                        </tr>


                    </tbody>
                </table>
                <input type="submit" value="Search Customer" />

            </form>
            </div>
            <div>
                    <br />
                    <form onSubmit={this.getInitialState}>
                        <input type="submit" value="Clear Form" />
                    </form>
            </div>
        </div>
        );
    }
});

var CustomerUpdateform = React.createClass({
    getInitialState: function () {
        return {
            upcustomerkey: "",
            upcustomername: "",
            upcustomeraddress: "",
            upcustomerzip: "",
            upcustomercredit: "",
            upcustomeremail: "",
            upcustomermember: "",
            upselectedOption: "",
            updata: []
        };
    },
    handleUpOptionChange: function (e) {
        this.setState({
            upselectedOption: e.target.value
        });
    },
    loadCustTypes: function () {
        $.ajax({
            url: '/getctypes',
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ updata: data });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
    },
    componentDidMount: function () {
        this.loadCustTypes();

    },
    handleUpSubmit: function (e) {
        e.preventDefault();

        var upcustomerkey = upckey.value;
        var upcustomername = upcname.value;
        var upcustomeraddress = upcaddress.value;
        var upcustomerzip = upczip.value;
        var upcustomercredit = upccredit.value;
        var upcustomeremail = upcemail.value;
        var upcustomermember = this.state.upselectedOption;
        var upcustomertype = upcusttype.value;

        this.props.onUpdateSubmit({
            upcustomerkey: upcustomerkey,
            upcustomername: upcustomername,
            upcustomeraddress: upcustomeraddress,
            upcustomerzip: upcustomerzip,
            upcustomercredit: upcustomercredit,
            upcustomeremail: upcustomeremail,
            upcustomermember: upcustomermember,
            upcustomertype: upcustomertype
        });
    },
    handleUpChange: function (event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    },
    render: function () {

        return (
            <div>
                <div id="theform">
                    <form onSubmit={this.handleUpSubmit}>

                        <table>
                            <tbody>
    <tr>
        <th>Customer Name</th>
        <td>
<input type="text" name="upcname" id="upcname" value={this.state.upcname} onChange={this.handleUpChange} />
        </td>
    </tr>
    <tr>
        <th>Customer Address</th>
        <td>
<input name="upcaddress" id="upcaddress" value={this.state.upcaddress} onChange={this.handleUpChange} />
        </td>
    </tr>
    <tr>
        <th>Customer Zip</th>
        <td>
<input name="upczip" id="upczip" value={this.state.upczip} onChange={this.handleUpChange} />
        </td>
    </tr>
    <tr>
        <th>Customer Credit</th>
        <td>
<input name="upccredit" id="upccredit" value={this.state.upccredit} onChange={this.handleUpChange} />
        </td>
    </tr>
    <tr>
        <th>Customer Email</th>
        <td>
<input name="upcemail" id="upcemail" value={this.state.upcemail} onChange={this.handleUpChange} />
        </td>
    </tr>
    <tr>
        <th>
            Become a Discount Member
        </th>
        <td>
            <input
                type="radio"
                name="upcustmember"
                id="upcustmemberyes"
                value="1"
                checked={this.state.upselectedOption === "1"}
                onChange={this.handleUpOptionChange}
                className="form-check-input"
            />Discount Member
                <input
                type="radio"
                name="upcustmember"
                id="upcustmemberno"
                value="0"
                checked={this.state.upselectedOption === "0"}
                onChange={this.handleUpOptionChange}
                className="form-check-input"
            />Normal Member
        </td>
    </tr>
    <tr>
        <th>
            Reward Status
        </th>
        <td>
            <SelectUpdateList data={this.state.updata} />
        </td>
    </tr>
</tbody>
                        </table><br />
                        <input type="hidden" name="upckey" id="upckey" onChange={this.handleUpChange} />
                        <input type="submit" value="Update Customer" />
                    </form>
                </div>
            </div>
        );
    }
});

var CustomerList = React.createClass({
    render: function () {
        var customerNodes = this.props.data.map(function (customer) {
            return (
                <Customer
                ckey={customer.dbcustomerkey}
                cname={customer.dbcustomername}
                caddress={customer.dbcustomeraddress}
                czip={customer.dbcustomerzip}
                ccredit={customer.dbcustomercredit}
                cemail={customer.dbcustomeremail}
                custmember={customer.dbcustomermember}
                customertype={customer.dbcrewardtype}
                >
                </Customer>
            );
                       
        });
        
        //print all the nodes in the list
        return (
             <tbody>
                {customerNodes}
            </tbody>
        );
    }
});

var Customer = React.createClass({
    getInitialState: function () {
        return {
            upckey: "",
            singledata: []
        };
    },
    updateRecord: function (e) {
        e.preventDefault();
        var theupckey = this.props.ckey;
        
        this.loadSingleCust(theupckey);
    },
    loadSingleCust: function (theupckey) {
        $.ajax({
            url: '/getsinglecust',
            data: {
                'upckey': theupckey
            },
            dataType: 'json',
            cache: false,
            success: function (data) {
                this.setState({ singledata: data });
                console.log(this.state.singledata);
                var populateCust = this.state.singledata.map(function (customer) {
                    upckey.value = theupckey;
                    upcname.value = customer.dbcustomername;
                    upcaddress.value = customer.dbcustomeraddress;
                    upczip.value = customer.dbcustomerzip;
                    upccredit.value = customer.dbcustomercredit;
                    upcemail.value = customer.dbcustomeremail;
                    if (customer.dbcustomermember == 1) {
                        upcustmemberyes.checked = true;
                    } else {
                        upcustmemberno.checked = true;
                    }
                    upcusttype.value = customer.dbcustomertype;

                });
            }.bind(this),
            error: function (xhr, status, err) {
                console.error(this.props.url, status, err.toString());
            }.bind(this)
        });
        
    },

    render: function () {
        
        if (this.props.custmember == 1) {
            var themember = "Discount Member";
        } else {
            var themember = "Normal Member";
        }

        return (

            <tr>
                            <td>
                                {this.props.ckey} 
                            </td>
                            <td>
                                {this.props.cname}
                            </td>
                            <td>
                                {this.props.caddress}
                            </td>
                            <td>
                                {this.props.czip}
                            </td>
                            <td>
                                <form onSubmit={this.updateRecord}>
                                    <input type="submit" value="Update Record" />
                                </form>
                            </td>
                </tr>
        );
    }
});

var SelectList = React.createClass ({
    render: function () {
        var optionNodes = this.props.data.map(function (custTypes) {
            return (
                <option
                    key={custTypes.dbcrewardid}
                    value={custTypes.dbcrewardid}
                >
                    {custTypes.dbcrewardtype}
                </option>
            );
        });
        return (
            <select name = "custtype" id = "custtype">
                <option value ="0"></option>
                {optionNodes}
            </select>
        );
    }
});

var SelectUpdateList = React.createClass({
    render: function () {
        var optionNodes = this.props.data.map(function (custTypes) {
            return (
                <option
                    key={custTypes.dbcrewardid}
                    value={custTypes.dbcrewardid}
                >
                    {custTypes.dbcrewardtype}
                </option>
            );
        });
        return (
            <select name="upcusttype" id="upcusttype">
                <option value="0"></option>
                {optionNodes}
            </select>
        );
    }
});

ReactDOM.render(
    <CustomerBox />,
    document.getElementById('content')
);